import { useState } from "react";

const MAX_STARS = 5;

type Movie = {
  id: number;
  title: string;
  rating: number;
  review: string;
};

type StarPickerProps = {
  value: number;
  onChange: (n: number) => void;
};

function StarPicker({ value, onChange }: StarPickerProps) {
  return (
    <div className="star-picker">
      {Array.from({ length: MAX_STARS }, (_, i) => i + 1).map((n) => (
        <button
          key={n}
          type="button"
          className={`star-btn ${n <= value ? "on" : ""}`}
          onClick={() => onChange(n === value ? 0 : n)}
          aria-label={`${n} star${n > 1 ? "s" : ""}`}
        >
          ★
        </button>
      ))}
    </div>
  );
}

type MovieItemProps = {
  movie: Movie;
  onRemove: (id: number) => void;
};

function MovieItem({ movie, onRemove }: MovieItemProps) {
  return (
    <li className="movie">
      <div className="movie-body">
        <h3 className="movie-title">{movie.title}</h3>
        <p className="movie-stars">
          {movie.rating > 0 ? "⭐".repeat(movie.rating) : "No rating"}
        </p>
        <p className={`movie-review ${movie.review ? "" : "none"}`}>
          {movie.review || "No review yet"}
        </p>
      </div>
      <button
        className="btn-delete"
        onClick={() => onRemove(movie.id)}
        aria-label={`Delete ${movie.title}`}
      >
        <svg
          viewBox="0 0 16 16"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
        >
          <path d="M3 3l10 10M13 3L3 13" />
        </svg>
      </button>
    </li>
  );
}

export default function App() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [title, setTitle] = useState("");
  const [review, setReview] = useState("");
  const [rating, setRating] = useState(0);

  const addMovie = () => {
    const trimmed = title.trim();
    if (!trimmed) return;

    setMovies((prev) => [
      ...prev,
      { id: Date.now(), title: trimmed, rating, review: review.trim() }
    ]);

    setTitle("");
    setReview("");
    setRating(0);
  };

  const removeMovie = (id: number) => {
    setMovies((prev) => prev.filter((m) => m.id !== id));
  };

  const clearAll = () => setMovies([]);

  const totalStars = movies.reduce((sum, m) => sum + m.rating, 0);

  return (
    <div className="app">
      <h1 className="app-title">🎬 Movies Watch List</h1>

      <div className="add-row">
        <input
          className="input"
          type="text"
          placeholder="Movie title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && addMovie()}
        />
        <button className="btn-add" onClick={addMovie}>
          Add
        </button>
      </div>

      <textarea
        className="textarea"
        placeholder="Write a short review..."
        value={review}
        onChange={(e) => setReview(e.target.value)}
      />

      <div className="rating-row">
        <span className="rating-label">Your rating:</span>
        <StarPicker value={rating} onChange={setRating} />
      </div>
      <p className="hint">Click the same star again to clear the rating</p>

      <ul className="movie-list">
        {movies.map((m) => (
          <MovieItem key={m.id} movie={m} onRemove={removeMovie} />
        ))}
      </ul>

      {movies.length > 0 && (
        <div className="footer">
          <span className="footer-info">
            {movies.length} {movies.length === 1 ? "movie" : "movies"} ·{" "}
            {totalStars} ⭐ given
          </span>
          <button onClick={clearAll}>Clear all</button>
        </div>
      )}
    </div>
  );
}
