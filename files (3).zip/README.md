# Lab 5 - Movies Watch List

Web Development (CSE343) - Yassin Bassem Sheta (24P0378)

A small React + TypeScript app where you can add movies with a short review and a 1-5 star rating, delete single movies, or clear the whole list.

## Run

```bash
npm install
npm start
```
